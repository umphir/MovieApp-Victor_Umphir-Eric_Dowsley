import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:movie_app/common/myhttp.dart';
import 'package:movie_app/common/utils.dart';
import 'package:movie_app/widgets/bottom_nav_bar.dart';
import 'package:movie_app/services/api_services.dart';
import 'package:movie_app/pages/home/widgets/favorites_manager.dart';

void main() {
  HttpOverrides.global = MyHttpOverrides();
  runApp(
    MultiProvider(
      providers: [
        Provider<ApiServices>(
          create: (_) => ApiServices(),
        ),
        ChangeNotifierProvider(
          create: (context) => FavoritesManager(context.read<ApiServices>()),
        ),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Movie App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        scaffoldBackgroundColor: BackgroundColor,
        appBarTheme: const AppBarTheme(
          backgroundColor: BackgroundColor,
          elevation: 0,
        ),
        bottomNavigationBarTheme: const BottomNavigationBarThemeData(
          backgroundColor: BackgroundColor,
        ),
      ),
      home: const BottomNavBar(),
    );
  }
}