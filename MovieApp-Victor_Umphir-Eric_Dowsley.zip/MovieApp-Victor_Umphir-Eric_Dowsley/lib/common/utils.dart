import 'package:flutter/material.dart';

// API related constants
const String apiKey = '10477b0194c1313663dd756fac20cb75';
const String baseUrl = 'https://api.themoviedb.org/3';
const String imageUrl = 'https://image.tmdb.org/t/p/w500';
// Color constants
const Color BackgroundColor = Color(0xFF121012);
const Color ButtonColor = Color(0xFF593685);
const Color BackgroundPrimary = Color(0xFFABA9B4);

// Text styles
const TextStyle headlineStyle = TextStyle(
  fontSize: 24,
  fontWeight: FontWeight.bold,
  color: Colors.white,
);

const TextStyle bodyStyle = TextStyle(
  fontSize: 16,
  color: Colors.white,
);

// Padding constants
const EdgeInsets pagePadding = EdgeInsets.all(16.0);
const EdgeInsets cardPadding = EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0);

// Utility functions
String formatRating(double rating) {
  return rating.toStringAsFixed(1);
}

String getFullImageUrl(String? path) {
  if (path == null || path.isEmpty) {
    return 'https://via.placeholder.com/500x750.png?text=No+Image';
  }
  return '$imageUrl$path';
}