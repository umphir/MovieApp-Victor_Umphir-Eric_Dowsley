import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:movie_app/models/movie_model.dart';
import 'package:movie_app/common/utils.dart';

class ApiServices {
  String _buildUrl(String endpoint, [Map<String, String>? queryParams]) {
    final params = {'api_key': apiKey};
    if (queryParams != null) {
      params.addAll(queryParams);
    }
    return Uri.https('api.themoviedb.org', '/3/$endpoint', params).toString();
  }

  Future<List<Movie>> _getMovieList(String endpoint, [Map<String, String>? map]) async {
    final url = _buildUrl(endpoint);
    print('URL da API: $url'); // Para debug

    try {
      final response = await http.get(Uri.parse(url));
      
      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);
        final List<dynamic> results = data['results'];
        return results.map((movieData) => Movie.fromJson(movieData)).toList();
      } else {
        throw Exception('Falha ao carregar filmes. Status: ${response.statusCode}');
      }
    } catch (e) {
      print('Erro ao buscar filmes: $e');
      rethrow;
    }
  }

  Future<List<Movie>> getMovies() async {
    // Agora busca filmes reais da API
    return _getMovieList('movie/now_playing');
  }

  Future<List<Movie>> getNowPlayingMovies() async {
    return _getMovieList('movie/now_playing');
  }

  Future<List<Movie>> getPopularMovies() async {
    return _getMovieList('movie/popular');
  }

  Future<List<Movie>> getUpcomingMovies() async {
    return _getMovieList('movie/upcoming');
  }

  Future<Movie> getMovieDetails(int movieId) async {
    final url = _buildUrl('movie/$movieId');
    print('URL da API para detalhes do filme: $url'); // Para debug

    try {
      final response = await http.get(Uri.parse(url));
      
      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);
        return Movie.fromJson(data);
      } else {
        print('Resposta da API: ${response.body}'); // Para debug
        throw Exception('Falha ao carregar detalhes do filme. Status: ${response.statusCode}');
      }
    } catch (e) {
      print('Erro ao buscar detalhes do filme: $e');
      rethrow;
    }
  }

 Future<List<Movie>> getTopRatedMovies() async {
  try {
    final List<Movie> movies = await _getMovieList('movie/top_rated');
    return movies.isNotEmpty ? movies : [];
  } catch (e) {
    print('Erro ao buscar filmes mais bem avaliados: $e');
    return []; // Retorna uma lista vazia em caso de erro
  }
}

   Future<List<Movie>> searchMovies(String query) async {
    final url = _buildUrl('search/movie', {'query': query});
    print('URL da API: $url'); // Para debug

    try {
      final response = await http.get(Uri.parse(url));
      
      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);
        final List<dynamic> results = data['results'];
        return results.map((movieData) => Movie.fromJson(movieData)).toList();
      } else {
        throw Exception('Falha ao pesquisar filmes. Status: ${response.statusCode}');
      }
    } catch (e) {
      print('Erro ao pesquisar filmes: $e');
      rethrow;
    }
  }
}