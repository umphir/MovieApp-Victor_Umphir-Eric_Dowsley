import 'package:flutter/material.dart';
import 'package:movie_app/common/utils.dart';
import 'package:provider/provider.dart';
import 'package:movie_app/pages/home/widgets/favorites_manager.dart';
import 'package:movie_app/pages/home/widgets/movie_details_screen.dart';
import 'package:movie_app/models/movie_model.dart';

class FavoritesPage extends StatelessWidget {
 const FavoritesPage({super.key});


  @override
  Widget build(BuildContext context) {
    return Consumer<FavoritesManager>(
      builder: (context, favoritesManager, child) {
        return Scaffold(
          appBar: AppBar(
            title: Text('Favoritos'),
          ),
          body: FutureBuilder<List<Movie>>(
            future: favoritesManager.getFavoriteMovies(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Center(child: CircularProgressIndicator());
              }
              if (snapshot.hasError) {
                return Center(child: Text('Erro ao carregar favoritos'));
              }
              final favoriteMovies = snapshot.data ?? [];
              if (favoriteMovies.isEmpty) {
                return Center(child: Text('Você ainda não tem filmes favoritos.'));
              }
              return ListView.builder(
                itemCount: favoriteMovies.length,
                itemBuilder: (context, index) {
                  final movie = favoriteMovies[index];
                  return ListTile(
                    leading: Image.network('$imageUrl${movie.posterPath}'),
                    title: Text(movie.title),
                    subtitle: Text(movie.releaseDate?.year.toString() ?? 'N/A'),
                    trailing: IconButton(
                      icon: Icon(Icons.favorite, color: Colors.red),
                      onPressed: () => favoritesManager.toggleFavorite(movie),
                    ),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => MovieDetailsScreen(movieId: movie.id),
                        ),
                      );
                    },
                  );
                },
              );
            },
          ),
        );
      },
    );
  }
}