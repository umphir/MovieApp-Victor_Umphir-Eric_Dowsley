import 'package:flutter/material.dart';
import 'package:movie_app/models/movie_model.dart';
import 'package:movie_app/services/api_services.dart';
import 'package:movie_app/common/utils.dart';

class MovieDetailsScreen extends StatelessWidget {
  final int movieId;
  final ApiServices apiServices = ApiServices();

  MovieDetailsScreen({Key? key, required this.movieId}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detalhes do Filme'),
      ),
      body: FutureBuilder<Movie>(
        future: apiServices.getMovieDetails(movieId),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return _buildErrorWidget(context, snapshot.error.toString());
          } else if (snapshot.hasData) {
            return _buildMovieDetails(context, snapshot.data!);
          } else {
            return Center(child: Text('Nenhum dado disponível'));
          }
        },
      ),
    );
  }

  Widget _buildErrorWidget(BuildContext context, String error) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Erro ao carregar detalhes do filme',
              style: TextStyle(fontSize: 18),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 8),
            Text(
              'ID do filme: $movieId\nErro: $error',
              style: TextStyle(fontSize: 14, color: Colors.red),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Voltar'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMovieDetails(BuildContext context, Movie movie) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildBackdropImage(movie.backdropPath),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  movie.title,
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 8),
                _buildInfoRow('Lançamento', movie.releaseDate?.year.toString() ?? 'N/A'),
                _buildInfoRow('Avaliação', '${movie.voteAverage.toStringAsFixed(1)}/10'),
                SizedBox(height: 16),
                Text(
                  'Sinopse',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 8),
                Text(movie.overview),
                SizedBox(height: 16),
                _buildGenreChips(movie.genreIds),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBackdropImage(String? backdropPath) {
    return backdropPath != null
        ? Image.network(
            '$imageUrl$backdropPath',
            height: 200,
            width: double.infinity,
            fit: BoxFit.cover,
            errorBuilder: (context, error, stackTrace) =>
                Container(
                  height: 200,
                  color: Colors.grey[300],
                  child: Center(child: Icon(Icons.error)),
                ),
          )
        : Container(
            height: 200,
            color: Colors.grey[300],
            child: Center(child: Icon(Icons.movie)),
          );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        children: [
          Text('$label: ', style: TextStyle(fontWeight: FontWeight.bold)),
          Text(value),
        ],
      ),
    );
  }

  Widget _buildGenreChips(List<int> genreIds) {
    // Você precisará de um mapa de gêneros para converter IDs em nomes
    // Este é um exemplo simplificado
    final genreNames = genreIds.map((id) => 'Gênero $id').toList();

    return Wrap(
      spacing: 8.0,
      children: genreNames.map((name) => Chip(label: Text(name))).toList(),
    );
  }
}