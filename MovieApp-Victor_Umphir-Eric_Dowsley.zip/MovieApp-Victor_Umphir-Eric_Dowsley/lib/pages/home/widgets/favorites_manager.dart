import 'package:flutter/foundation.dart';
import 'package:movie_app/models/movie_model.dart';
import 'package:movie_app/services/api_services.dart';

class FavoritesManager extends ChangeNotifier {
  final Set<int> _favoriteIds = {};
  final ApiServices _apiServices;

  FavoritesManager(this._apiServices);

  bool isFavorite(int movieId) => _favoriteIds.contains(movieId);

  void toggleFavorite(Movie movie) {
    if (_favoriteIds.contains(movie.id)) {
      _favoriteIds.remove(movie.id);
    } else {
      _favoriteIds.add(movie.id);
    }
    notifyListeners();
  }

  Future<List<Movie>> getFavoriteMovies() async {
    List<Movie> favoriteMovies = [];
    for (int id in _favoriteIds) {
      try {
        Movie movie = await _apiServices.getMovieDetails(id);
        favoriteMovies.add(movie);
      } catch (e) {
        print('Erro ao carregar filme favorito com ID $id: $e');
      }
    }
    return favoriteMovies;
  }
}