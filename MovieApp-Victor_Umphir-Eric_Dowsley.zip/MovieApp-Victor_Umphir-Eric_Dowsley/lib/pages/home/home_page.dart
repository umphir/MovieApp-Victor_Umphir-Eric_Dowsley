import 'package:flutter/material.dart';
import 'package:movie_app/models/movie_model.dart';
import 'package:movie_app/pages/home/widgets/movies_horizontal_list.dart';
import 'package:movie_app/pages/home/widgets/nowplaying_list.dart';
import 'package:movie_app/services/api_services.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final ApiServices apiServices = ApiServices();
  late Future<List<Movie>> nowPlayingMovies;
  late Future<List<Movie>> popularMovies;
  late Future<List<Movie>> upcomingMovies;

  @override
  void initState() {
    super.initState();
    nowPlayingMovies = apiServices.getNowPlayingMovies();
    popularMovies = apiServices.getPopularMovies();
    upcomingMovies = apiServices.getUpcomingMovies();
  }

  Widget _buildMovieSection(String title, Future<List<Movie>> moviesFuture, Widget Function(List<Movie>) builder) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 5),
          child: Text(
            title,
            style: TextStyle(
              color: Colors.white54,
              fontWeight: FontWeight.w300,
              fontSize: 20,
            ),
          ),
        ),
        FutureBuilder<List<Movie>>(
          future: moviesFuture,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(child: CircularProgressIndicator());
            }
            if (snapshot.hasError) {
              return Center(child: Text('Error: ${snapshot.error}'));
            }
            if (snapshot.hasData && snapshot.data!.isNotEmpty) {
              return builder(snapshot.data!);
            }
            return Center(child: Text('No data found'));
          },
        ),
        SizedBox(height: 20),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Movie App'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildMovieSection('Now Playing', nowPlayingMovies, (movies) => NowPlayingList(movies: movies)),
              _buildMovieSection('Popular', popularMovies, (movies) => MoviesHorizontalList(movies: movies)),
              _buildMovieSection('Upcoming', upcomingMovies, (movies) => MoviesHorizontalList(movies: movies)),
            ],
          ),
        ),
      ),
    );
  }
}